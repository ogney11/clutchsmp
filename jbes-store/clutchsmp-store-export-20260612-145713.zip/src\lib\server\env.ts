export function getRequiredEnv(name: string) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export function getServerErrorMessage(error: unknown) {
  if (error instanceof Error && error.message.startsWith("Missing required environment variable:")) {
    return "Payment backend is not configured yet. Add the required values to .env.local, then restart the dev server.";
  }

  if (error instanceof Error && error.message.includes("orders_payment_method_check")) {
    return "Database schema needs the BLIK update. Run the latest supabase/schema.sql in Supabase, then retry checkout.";
  }

  if (error instanceof Error && error.message === "TypeError: fetch failed") {
    return "Payment backend could not reach Stripe or Supabase. Restart the app with npm run dev so Node uses the Windows certificate store.";
  }

  return error instanceof Error ? error.message : "Unexpected server error.";
}

export function getBaseUrl() {
  return (
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.VERCEL_PROJECT_PRODUCTION_URL?.replace(/^/, "https://") ||
    "http://localhost:3000"
  );
}
